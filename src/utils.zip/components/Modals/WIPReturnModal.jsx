import React from "react";

const WIPReturnModal = () => {
  return <div>WIPReturn</div>;
};

export default WIPReturnModal;
