import React from "react";

const BOMModel = () => {
  return <div>BOM</div>;
};

export default BOMModel;
