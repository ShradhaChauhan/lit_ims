import React from "react";

const IncomingReprint = () => {
  return <div>IncomingReprint</div>;
};

export default IncomingReprint;
