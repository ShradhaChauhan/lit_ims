import React from "react";

const IncomingModal = () => {
  return <div>Incoming Modal</div>;
};

export default IncomingModal;
