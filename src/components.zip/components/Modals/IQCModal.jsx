import React from "react";

const IQCModal = () => {
  return <div>IQC Modal</div>;
};

export default IQCModal;
