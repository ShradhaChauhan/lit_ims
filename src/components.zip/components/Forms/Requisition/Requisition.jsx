import React from "react";

const Requisition = () => {
  return <div>Requisition</div>;
};

export default Requisition;
