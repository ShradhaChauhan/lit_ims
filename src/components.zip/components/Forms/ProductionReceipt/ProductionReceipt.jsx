import React from "react";

const ProductionReceipt = () => {
  return <div>ProductionReceipt</div>;
};

export default ProductionReceipt;
