import React from "react";

const RequisitionReceipt = () => {
  return <div>RequisitionReceipt</div>;
};

export default RequisitionReceipt;
