import React from "react";

const Incoming = () => {
  return <div>Incoming</div>;
};

export default Incoming;
