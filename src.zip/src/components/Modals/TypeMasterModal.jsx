import React from "react";

const TypeMasterModal = () => {
  return <div>TypeMaster Modal</div>;
};

export default TypeMasterModal;
