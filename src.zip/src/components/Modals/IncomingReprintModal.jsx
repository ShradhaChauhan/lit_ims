import React from "react";

const IncomingReprintModal = () => {
  return <div>IncomingReprint</div>;
};

export default IncomingReprintModal;
