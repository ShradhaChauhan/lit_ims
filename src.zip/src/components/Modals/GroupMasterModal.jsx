import React from "react";

const GroupMasterModal = () => {
  return <div>GroupMaster Modal</div>;
};

export default GroupMasterModal;
