import React from "react";

const RequisitionModal = () => {
  return <div>Requisition</div>;
};

export default RequisitionModal;
