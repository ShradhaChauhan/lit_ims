import React from "react";

const ProductionReceiptModal = () => {
  return <div>ProductionReceipt</div>;
};

export default ProductionReceiptModal;
