import React from "react";

const WarehouseMasterModal = () => {
  return <div>WarehouseMaster</div>;
};

export default WarehouseMasterModal;
