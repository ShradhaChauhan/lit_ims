import React from "react";

const RequisitionReceiptModal = () => {
  return <div>RequisitionReceipt</div>;
};

export default RequisitionReceiptModal;
