import React from "react";

const PartMasterModal = () => {
  return <div>PartMaster</div>;
};

export default PartMasterModal;
