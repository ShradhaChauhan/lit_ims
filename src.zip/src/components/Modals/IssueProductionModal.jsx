import React from "react";

const IssueProductionModal = () => {
  return <div>IssueProduction</div>;
};

export default IssueProductionModal;
